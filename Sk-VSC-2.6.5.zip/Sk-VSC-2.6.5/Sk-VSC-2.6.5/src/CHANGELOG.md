# Changelog

### v2.6.5
> Fixed some compatibility issues with other extensions (Thanks @TheLividX)  
> Dropped support for Sublime Text 3 (unmaintained anymore)  

### v2.6.4
> Added folding! Useful for categorising your code!

Example:
```
#!FOLD [NAME]
> YOUR CODE HERE
#!UNFOLD
```

### v2.6.3

> Added new theme 'Shades of Purple'


### v2.6.0

> (+) Added new comment style **'#!!'** without the single qoutes, it will show as dark green comment (for dark green comments fans)

> (+) Added new theme (Material Palenight & Material Palenight High Contrast)

> (+) Changed comments to italic

> (\*) Improved comments highlighting handling

> (\*) Fixed boundries of many skript types such as 'int'

Added some new grammars:
```
 - [un]load[ed]
 - (of|on) file
 - server command
 - exist[s]
 - empty
 - y[a]ml (value|nodes|list|node[s with] keys)
 - play[ed]
 - (this|server|before)
 - (complete|absolute|path|absorption hearts|accepted items|tablist|group|score|all|holo[gram]s)
 - for
 ```
